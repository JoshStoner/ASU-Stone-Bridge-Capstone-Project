//
//  InspectionFormEntity+CoreDataClass.swift
//  StoneBride Well Inspection
//
//  Created by Tyler Ipema on 2/3/21.
//  Copyright © 2021 ASU. All rights reserved.
//
//

import Foundation
import CoreData

@objc(InspectionFormEntity)
public class InspectionFormEntity: NSManagedObject {

}
